package com.centropokemon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentroPokemonApplicationTests {

	@Test
	void contextLoads() {
	}

}
