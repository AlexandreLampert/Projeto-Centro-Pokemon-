# Centro Pokémon - Spring Boot scaffold

This is a ready-to-run Spring Boot scaffold for your Centro Pokémon frontend.

## Como usar

1. Verifique ter instalado:
   - JDK 17+
   - Maven

2. No terminal, execute:
```
cd centro-pokemon
mvn spring-boot:run
```

3. Abra no navegador:
```
http://localhost:8080/Pokemon.html
```

## Onde você implementa a lógica Java

- `com.centropokemon.service.PokedexService` - interface com o método `fetchPokemon(String nameOrId)`.
- `com.centropokemon.service.DummyPokedexService` - implementação de exemplo (dummy). Substitua essa classe por uma que:
  - Use `RestTemplate` ou `WebClient` para chamar `https://pokeapi.co/api/v2/pokemon/{nameOrId}`
  - Converta o JSON retornado para um `Map<String,Object>` com os campos esperados pelo frontend
  - Você pode manter o bean com `@Service` para injetar no `PokedexController`.

- `com.centropokemon.controller.PokedexController` - já está pronto para usar o service.

### Dicas rápidas
- Exemplo usando `RestTemplate`:
```java
RestTemplate rest = new RestTemplate();
String url = "https://pokeapi.co/api/v2/pokemon/" + nameOrId;
Map<String,Object> response = rest.getForObject(url, Map.class);
```

- Para conversão de objetos JSON, você pode usar `ObjectMapper` (Jackson) que já vem com Spring Boot.

Bom trabalho — se quiser eu já substituo `DummyPokedexService` por uma implementação completa usando `RestTemplate` para você comparar. Deseja que eu faça isso ou prefere implementar os métodos você mesmo? 
