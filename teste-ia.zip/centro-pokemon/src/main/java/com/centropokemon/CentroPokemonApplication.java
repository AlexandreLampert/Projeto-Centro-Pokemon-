/*
 * Centro Pokémon - Aplicação Principal
 * ------------------------------------
 * @file        CentroPokemonApplication.java
 * @author      Gustavo Pigatto, Matheus Schvann
 * @version     1.0
 * @date        2025-10-29
 * @description Classe principal responsável por iniciar a aplicação Spring Boot do Centro Pokémon.
 */

package com.centropokemon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CentroPokemonApplication {

	public static void main(String[] args) {
		SpringApplication.run(CentroPokemonApplication.class, args);
	}
}
