/*
 * Centro Pokémon - Controlador da Pokédex
 * ---------------------------------------
 * @file        PokedexController.java
 * @author      Gustavo Pigatto, Matheus Schvann
 * @version     1.0
 * @date        2025-10-29
 * @description Controlador responsável pelos endpoints da Pokédex via API.
 */

package com.centropokemon.controller;

import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.centropokemon.service.PokedexService;

@RestController
@RequestMapping("/api/pokedex")
public class PokedexController {

	private final PokedexService pokedexService;

	public PokedexController(PokedexService pokedexService) {
		this.pokedexService = pokedexService;
	}

	@GetMapping("/{name}")
	public ResponseEntity<Map<String, Object>> getPokemon(@PathVariable String name) {
		Map<String, Object> pokemon = pokedexService.buscarPokemon(name);
		if (pokemon == null || pokemon.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(pokemon);
	}
}
