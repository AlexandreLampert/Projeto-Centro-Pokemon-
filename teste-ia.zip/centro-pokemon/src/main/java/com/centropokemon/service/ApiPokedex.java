/*
 * Centro Pokémon - Implementação da Pokédex API
 * ------------------------------------------
 * @file        ApiPokedex.java
 * @author      Gustavo Pigatto, Matheus Schvann
 * @version     1.0
 * @date        2025-10-29
 * @description Implementação simples do serviço da Pokédex API.
 *              Retorna dados de um Pokémon ( Agora no base um exemplo apenas, não implementado ainda ).
 */

package com.centropokemon.service;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class ApiPokedex implements PokedexService {

	@Override
	public Map<String, Object> buscarPokemon(String nomeOuId) {

		Map<String, Object> dadosPokemon = new HashMap<>();
		dadosPokemon.put("id", 25);
		dadosPokemon.put("nome", "Pikachu");
		dadosPokemon.put("altura", 4);
		dadosPokemon.put("peso", 60);
		dadosPokemon.put("types",
				Arrays.asList(Collections.singletonMap("type", Collections.singletonMap("name", "electric"))));
		dadosPokemon.put("abilities",
				Arrays.asList(Collections.singletonMap("ability", Collections.singletonMap("name", "static"))));

		Map<String, Object> sprites = new HashMap<>();
		sprites.put("front_default", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png");

		dadosPokemon.put("sprites", sprites);
		return dadosPokemon;
	}
}
