/*
 * Centro Pokémon - Serviço da Pokédex ( API )
 * -----------------------------------
 * @file        PokedexService.java
 * @author      Gustavo Pigatto, Matheus Schvann
 * @version     1.0
 * @date        2025-10-29
 * @description Interface de serviço responsável por definir as operações da Pokédex.
 */

package com.centropokemon.service;

import java.util.Map;

public interface PokedexService {
	Map<String, Object> buscarPokemon(String nomeOuId);
}
